# EKB public test corpus downloader

Copy `scripts/download_test_corpus.py` and `config/test_corpus.yaml` into the root of your EKB repository.

Run from any directory (script resolves its repository root):

```bash
uv run --with httpx --with pyyaml python scripts/download_test_corpus.py
```

Output: `data/test-corpus/public/<source-category>/<source-id>.<extension>` with an `index.json` containing hashes and retrieval metadata.

Repeated runs send conditional requests when publishers provide ETag/Last-Modified; otherwise reuse cached files. Use `--force` to redownload. `--dry-run` prints intended output destinations. HTTP 403/404 or publisher URL changes are surfaced as failures and do not overwrite any existing good file.

Include in `.gitignore`:

```gitignore
/data/test-corpus/public/
```

The ISO entry downloads the public overview HTML, **not** the licensed ISO full text. Source applicability to any organization is not implied. Shell sometimes changes its direct report URLs; if one returns 404, replace the corresponding URL in `config/test_corpus.yaml` with the current PDF link from Shell's official report page.
